import streamlit as st
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
import pickle


##importing our model
pickle_in =open('gradientboostingclassifier.pkl','rb')
model = pickle.load(pickle_in)

#Dataset
iris_df = pd.read_csv('IRIS.csv')

##streamlit app
st.title('IRIS SPECIES PREDICTION')

st.sidebar.header('ENTER IRIS DETAILS')
 
Iris_petal_length = st.sidebar.number_input('Enter petal length: ', key =1)
Iris_petal_width = st.sidebar.number_input('Enter petal width: ',key = 2)
Iris_sepal_length = st.sidebar.number_input('Enter sepal length: ',key = 3)
Iris_sepal_width = st.sidebar.number_input('Enter sepal width: ', key =4)

prediction = model.predict([[Iris_petal_length,Iris_petal_width,Iris_sepal_length,Iris_sepal_width]])

if st.sidebar.button('Predict'):
    if prediction ==0:
        st.write('Based on the input this is an IRIS SETOSA') 
        st.image(r'iris_setosa.jfif')
    elif prediction==1:
        st.write('Based on the input this is an IRIS VERSICOLOR')
        st.image(r'iris_versicolor.jfif')
    else:
        st.write('Based on the input this is an IRIS VIRGINICA')
        st.image(r'iris_virginica.jfif')
